/*
 * SN74HC164SD.c
 *
 * Created: 7/8/2023 6:44:00 PM
 * Author : Admin
 */ 

#include <avr/io.h>

#define SW1  5
#define SDAT 7
#define SCLK 6

void send74hc164(unsigned char data){
	for(int i=0; i<8;i++){
		if ((data&(1<<7))==0)
		{
			PORTC&=~(1<<SDAT);
		}
		else PORTC|=(1<<SDAT);
		PORTC|=(1<<SCLK);
		for(int i=0;i<=50;i++);
		PORTC&=~(1<<SCLK);
		for(int i=0;i<=50;i++);
		data<<=1;
	}
}

unsigned char cCathode[]={0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F,0x77,0x7C,0x39,0x5E,0x79,0x71};
//unsigned char cAnode[]={0xC0,0xF9,0xA4,0xB0,0x99,0x92,0x82,0xF8,0x80,0x90,0x88,0x83,0xC6,0xA1,0x86,0x8E};
int main(void)
{
    unsigned char newData = 0, oldData = 0xFF;
	/*SW1 For Input Button*/
	DDRC&=~(1<<SW1);
	/*Set SW1 Pin High*/
	PORTC|=(1<<SW1);
	/*Serial Data And Serial Clock Output To SN74HC164*/
	DDRC|=(1<<SDAT)|(1<<SCLK);	
    while (1) 
    {
		if((PINC&(1<<SW1)) == 0){
			newData++;
			//while((PINC&(1<<SW1))==0);
			for(int i = 0; i <= 150; i++)
				for(int i = 0; i <= 1000; i++);
			if(newData > 0x0F) newData = 0;
		}
				
		if (newData != oldData)
		{
			send74hc164(cCathode[newData]);
			oldData = newData;
		}
    }
}

