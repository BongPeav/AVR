/*
 * EepromEx1.c
 *
 * Created: 7/20/2023 6:53:22 PM
 * Author : Admin
 */ 

#include <avr/io.h>

#include <avr/eeprom.h>

#define F_CPU 8000000UL
#include <util/delay.h>


int main(void)
{
	DDRC = 0xFF;
	for (uint8_t i= 0;i<0xFF;i++)
		eeprom_write_byte(i,i);
    while (1) 
    {	
		for (uint8_t i = 0; i<0xFF; i++)
		{
			PORTC = eeprom_read_byte(i);
			_delay_ms(250);
		}
			
    }
}

