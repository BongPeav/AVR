/*
 * 11-soft_twi_pcf8574T_1602.c
 *
 * Created: 2/12/2026 4:04:24 PM
 * Author : Admin
 */ 

#include <avr/io.h>
#include <util/delay.h>
#define F_CPU 16000000UL

/*TWI LCD Driver*/
#define RS  0
#define RW  1
#define EN  2
#define BL  3

#define twi_lcd_cursor_off()	twi_lcd_command(0x0C)
#define twi_lcd_line_1()		twi_lcd_command(0x80)
#define twi_lcd_line_2()		twi_lcd_command(0xC0)

char backLight=1;

void twi_lcd_command(uint8_t command){
	uint8_t data;
	data=command&0xF0;
	pcf8574_write(data|(backLight<<BL)|(1<<EN));
	//_delay_us(10);
	pcf8574_write(data|(backLight<<BL));
	//_delay_us(50);
	
	data=command<<4;
	pcf8574_write(data|(backLight<<BL)|(1<<EN));
	//_delay_us(10);
	pcf8574_write(data|(backLight<<BL));
	//_delay_us(50);
}

void twi_lcd_data(uint8_t command){
	uint8_t data;
	data=command&0xF0;
	pcf8574_write(data|(backLight<<BL)|(1<<EN)|(1<<RS));
	//_delay_us(10);
	pcf8574_write(data|(backLight<<BL)|(1<<RS));
	_delay_us(50);
	
	data=command<<4;
	pcf8574_write(data|(backLight<<BL)|(1<<EN)|(1<<RS));
	//_delay_us(10);
	pcf8574_write(data|(backLight<<BL)|(1<<RS));
	//_delay_us(50);
}

void twi_lcd_xy(int8_t x, int8_t y){
	int8_t addr[]={0x80,0xC0};
	twi_lcd_command(addr[y-1]+x-1);
}

void twi_lcd_text(int8_t *txt){
	while(*txt) twi_lcd_data(*txt++);
}

void twi_lcd_clear(void){
	twi_lcd_command(0x01);
	_delay_ms(5);
}

void twi_lcd_init(void){
	pcf8574_write(0);
	//_delay_ms(10);
	twi_lcd_command(0x33);
	//_delay_us(10);
	twi_lcd_command(0x32);
	//_delay_us(10);
	twi_lcd_command(0x28);
	//_delay_us(10);
	twi_lcd_command(0x0F);
	//_delay_us(10);
	twi_lcd_command(0x01);
	//_delay_ms(5);
	twi_lcd_command(0x06);
	//_delay_us(10);
}

int main(void)
{
    /* Replace with your application code */
	twi_lcd_init();
	twi_lcd_text("Software TWI");
	twi_lcd_line_2();
	twi_lcd_text("PCF8574T LCD");
	twi_lcd_cursor_off();
    while (1) 
    {
    }
}

