/*
 * soft_twi.c
 *
 * Created: 2/12/2026 4:06:53 PM
 *  Author: Admin
 */ 

#include <avr/io.h>

#define TWI_PORT PORTC
#define TWI_SDA_IN PINC
#define TWI_DIR  DDRC

const char SDA=1;
const char SCL=0;
const unsigned int PULSE=100;

//DS1307 and DS3231 RTC Chip
const char DS1307_W=0xD0;
const char DS1307_R=0xD1;
//AT24C16B 16kB EEPROM
const char AT24C16B_W=0xA0;
const char AT24C16B_R=0xA1;
//PCF8574 and PCF8574A Series
const char PCF8574_W=0x40;
const char PCF8574_R=0x41;
const char PCF8574A_W=0x70;
const char PCF8574A_R=0x71;
//DIY Arduino PCF8574T LCD Module
const char PCF8574T_LCD_W=0x4E;
const char PCF8574T_LCD_R=0x4F;
//SH1106 OLED Module
const char SH1106_W=0x78;
const char SH1106_R=0x79;
//MCP23017 GPIO Expansion
const char MCP23017_W=0x40;
const char MCP23017_R=0x41;

void delay_counts(unsigned int count){
	for(unsigned int i=0;i<count;i++);	
}

void twi_start(void){
	TWI_DIR|=(1<<SDA)|(1<<SCL);
	TWI_PORT|=(1<<SDA)|(1<<SCL);
	delay_counts(PULSE);
	TWI_PORT&=~(1<<SDA);
	delay_counts(PULSE);
	TWI_PORT&=~(1<<SCL);
	delay_counts(PULSE);
}

void twi_stop(void){
	TWI_DIR|=(1<<SDA)|(1<<SCL);
	TWI_PORT&=~(1<<SCL);
	TWI_PORT&=~(1<<SDA);
	TWI_PORT|=(1<<SCL);
	delay_counts(PULSE);
	TWI_PORT|=(1<<SDA);
	delay_counts(PULSE);
	TWI_PORT|=(1<<SDA)|(1<<SCL);
	delay_counts(PULSE);
}

void twi_write(char data){
	char temp=0;
	TWI_DIR|=(1<<SDA)|(1<<SCL);
	for (unsigned char i=0;i<9;i++)
	{
		TWI_PORT&=~(1<<SCL);
		delay_counts(PULSE);
		if(i<8){
			temp=data&0x80;
			if(temp==0) TWI_PORT&=~(1<<SDA);
			else TWI_PORT|=(1<<SDA);
		}		
		else{
			TWI_PORT&=~(1<<SDA);
			TWI_DIR&=~(1<<SDA);
			while(TWI_SDA_IN&(1<<SDA)==0);
		}	
		TWI_PORT|=(1<<SCL);
		delay_counts(PULSE);	
		data<<=1;
	}
	TWI_DIR|=(1<<SDA)|(1<<SCL);
}

char twi_read(void){
	char temp=0,data=0;
	TWI_DIR&=~(1<<SDA);
	for (unsigned char i=0;i<9;i++)
	{
		TWI_PORT&=~(1<<SCL);
		delay_counts(PULSE);
		TWI_PORT|=(1<<SCL);
		delay_counts(PULSE);
		
		
		
		if(i<8){
			/*
			data<<=1;
			temp=TWI_SDA_IN&(1<<SDA);
			if(temp==(1<<SDA)) data|=1;
			else data|=0;
			*/
			/*
			temp=TWI_SDA_IN&(1<<SDA);
			temp>>=1;
			data|=temp<<(7-i);						
			*/
			data<<=1;
			if (TWI_SDA_IN&(2))
			{
				data|=1;
			}		
		}
		else{		
			while((TWI_SDA_IN&(1<<SDA))==0);		
					
		}		
	}	
	return data;
}

//PCF8574T LCD Driver

void pcf8574_write(char data){
	twi_start();
	twi_write(PCF8574T_LCD_W);
	twi_write(data);
	twi_stop();
}

char pcf8574_read(void){
	twi_start();
	twi_write(PCF8574T_LCD_R);
	char temp=twi_read();
	twi_stop();
	return temp;
}