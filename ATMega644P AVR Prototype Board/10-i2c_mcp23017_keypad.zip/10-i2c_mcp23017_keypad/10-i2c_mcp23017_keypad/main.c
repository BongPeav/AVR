/*
 * 10-i2c_mcp23017_keypad.c
 *
 * Created: 2/5/2026 9:05:21 AM
 * Author : Admin
 */ 

#include <avr/io.h>
#include <util/delay.h>
#define F_CPU 16000000UL

const char MCP23017_W=0x40;
const char MCP23017_R=0x41;

//IOCON.BANK=0
enum BANK0{
	IODIRA=0,IODIRB,IPOLA,IPOLB,GPINTENA,GPINTENB,DEFVALA,
	DEFVALB,INTCONA,INTCONB,IOCON1,IOCON2,GPPUA,GPPUB,
	INTFA,INTFB,INTCAPA,INTCAPB,GPIOA,GPIOB,OLATA,OLATB
};


void mcp23017_write(char address,char data){
	twi_start();
	/*Select the write address*/
	twi_write(MCP23017_W);
	/*Select a register address*/
	twi_write(address);
	/*Send configuration data*/
	twi_write(data);
	twi_stop();
}

unsigned char mcp23017_read(char address){
	/*Select a specific address*/
	twi_start();
	twi_write(MCP23017_W);
	twi_write(address);
	twi_stop();
	/*Read data from the given address*/
	twi_start();
	twi_write(MCP23017_R);
	unsigned char i2cData=twi_read(1);
	twi_stop();
	return i2cData;
}

const char key_16[4][4]={'1','2','3','A',
						'4','5','6','B',
						'7','8','9','C',
						'*','0','#','D'};

char keyScan(void){
	char data=0,temp,key;
	for(char i=0;i<4;i++){
		data=0xFF;
		data&=~(1<<i);
		mcp23017_write(OLATA,data);
		_delay_ms(5);
		data=mcp23017_read(GPIOA);
		data&=0xF0;
		if((data&0x10)==0)     {temp=key_16[i][0]; break;}
		else if((data&0x20)==0){temp=key_16[i][1]; break;}
		else if((data&0x40)==0){temp=key_16[i][2]; break;}
		else if((data&0x80)==0){temp=key_16[i][3]; break;}
		else temp=0;
		_delay_ms(10);
	}
	return temp;
}

int main(void)
{
    /* Replace with your application code */
	lcd_init();
	twi_init();
	lcd_text("ATMEGA644P TWI");
	lcd_xy(1,2);
	lcd_text("MCP23017 KeyPad");
	_delay_ms(5000);
	lcd_clear();
	//Key Pad Init
	mcp23017_write(IODIRA,0xF0);
	mcp23017_write(GPPUA,0xF0);
	char temp,charCount=0,newLine=0,line=1;
    while (1) 
    {
		temp=keyScan();
		if(temp!=0){
			lcd_data(temp);
			charCount++;
			_delay_ms(500);
		}
		if(charCount>16){
			newLine=1;
			charCount=0;
			line+=1;
		}
		if(newLine){
			newLine=0;
			if(line==2) lcd_xy(1,2);
			else{
				lcd_xy(1,1);
				lcd_command(0x01);
				_delay_ms(5);
				line=1;
				
			}
		}
    }
}

