/*
 * 11-soft_twi_sh1106.c
 *
 * Created: 2/10/2026 12:03:22 AM
 * Author : Admin
 */ 

#include <avr/io.h>
#include <util/delay.h>
#define F_CPU 16000000UL

int main(void)
{
	/* Replace with your application code */
	_delay_ms(1000);
	display_init();
	display_clear(0);
	display_text_8x16(0,0,"SH1106 I2C OLED");
	display_text_8x16(0,1,"And ATMega644P");
	display_text_8x16(0,2,"Programming With");
	display_text_8x16(0,3,"Microchip Studio");
	_delay_ms(10000);
	display_clear(0x00);
	while (1)
	{
		display_text_8x16(0,0,"Software TWI");
		_delay_ms(2500);
		uint8_t h=15;
		for(uint8_t i=0;i<10;i++) {
			display_char_8x16(h,1,'0'+i);
			h+=10;
		}
		_delay_ms(2500);
		h=0;
		for(uint8_t i=0;i<14;i++) {
			display_char_8x16(h,2,'A'+i);
			h+=10;
		}
		_delay_ms(2500);
		h=0;
		for(uint8_t i=0;i<14;i++) {
			display_char_8x16(h,3,'N'+i);
			h+=10;
		}
		_delay_ms(10000);
		display_clear(255);
		_delay_ms(10000);
		display_clear(0);
		_delay_ms(1000);
	}
}