/*
 * hd44780.h
 *
 * Created: 1/28/2026 9:56:39 PM
 *  Author: Admin
 */ 


#ifndef HD44780_H_
#define HD44780_H_





#endif /* HD44780_H_ */

#include <avr/io.h>
#include <stdio.h>
#include <util/delay.h>
#define F_CPU 16000000UL

#define RS	2
#define EN	3

const char d_time=50;

void lcd_command(char command);
void lcd_data(char data);
void lcd_init(void);
void lcd_xy(char x, char y);
void lcd_text(char *text);
void lcd_clear(void);