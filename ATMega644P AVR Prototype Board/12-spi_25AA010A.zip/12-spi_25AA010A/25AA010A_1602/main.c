/*
 * 25AA010A_1602.c
 *
 * Created: 2/24/2026 9:36:19 PM
 * Author : Admin
 */ 

#include <avr/io.h>
#include <util/delay.h>
#define F_CPU 16000000UL

#define DDR_SPI DDRB
#define PRT_SPI PORTB

#define DD_SS 4
#define DD_MOSI 5
#define DD_MISO 6
#define DD_SCK 7

void SPI_MasterInit(void)
{
	/* Set MOSI and SCK output, all others input */
	DDR_SPI = (1<<DD_MOSI)|(1<<DD_SCK)|(1<<DD_SS);
	/* Enable SPI, Master, set clock rate fck/16 */
	SPCR = (1<<SPE)|(1<<MSTR)|(1<<SPR0);
}

void SPI_MasterTransmit(char cData)
{
	/* Start transmission */
	SPDR = cData;
	/* Wait for transmission complete */
	while(!(SPSR & (1<<SPIF)))
	;
}

void SPI_SlaveInit(void)
{
	/* Set MISO output, all others input */
	DDR_SPI = (1<<DD_MISO);
	/* Enable SPI */
	SPCR = (1<<SPE);
}
char SPI_SlaveReceive(void)
{
	/* Wait for reception complete */
	while(!(SPSR & (1<<SPIF)))
	;
	/* Return Data Register */
	return SPDR;
}

// 93AA46B SPI EEPROM

void write_enable(void){
	PRT_SPI&=~(1<<DD_SS);
	SPI_MasterTransmit(0x06);
	PRT_SPI|=(1<<DD_SS);
}

unsigned char read_status(void){
	PRT_SPI&=~(1<<DD_SS);
	SPI_MasterTransmit(0x05);
	SPI_MasterTransmit(0x00);
	unsigned char temp=SPI_SlaveReceive();
	PRT_SPI|=(1<<DD_SS);
	return temp;
}
void write_25AA010A(unsigned char address, unsigned char data){
	write_enable();
	unsigned char temp;
	PRT_SPI&=~(1<<DD_SS);
	SPI_MasterTransmit(0x02);
	SPI_MasterTransmit(address&0x7F);
	SPI_MasterTransmit(data);
	PRT_SPI|=(1<<DD_SS);
	//Check Write Busy Flag
	do
	{
		temp=read_status();
	} while ((temp&0x01)==1);
}

unsigned char read_25AA010A(unsigned char address){
	PRT_SPI&=~(1<<DD_SS);
	SPI_MasterTransmit(0x03);
	SPI_MasterTransmit(address&0x7F);
	SPI_MasterTransmit(0x00);	
	_delay_us(100);
	unsigned char data=SPI_SlaveReceive();
	PRT_SPI|=(1<<DD_SS);
	return data;
}

int main(void)
{
    /* Replace with your application code */
	SPI_MasterInit();
	PRT_SPI|=(1<<DD_SS);
	lcd_init();
	
	unsigned char temp[16]="ATMEGA644P SPI";
	for (unsigned char i=0;i<16;i++)
	{
		write_25AA010A(i,temp[i]);
	}
	for (unsigned char i=0;i<16;i++)
	{
		temp[i]=read_25AA010A(i);
	}
	lcd_text(temp);
	
	unsigned char temp_1[16]="25AA010A EEPROM";
	for (unsigned char i=16;i<32;i++)
	{
		write_25AA010A(i,temp_1[i]);
	}
	for (unsigned char i=16;i<32;i++)
	{
		temp_1[15-i]=read_25AA010A(i);
	}
	lcd_xy(1,2);
	lcd_text(temp_1);
	
    while (1) 
    {
		
    }
}






