/*
 * adc.c
 *
 * Created: 2/10/2026 9:57:34 PM
 *  Author: Admin
 */ 

#include <avr/io.h>

void adc_init(void){
	/*Set PA0 and PA1 to input*/
	DDRA&=~(1<<0);
	DDRA&=~(1<<1);
	ADCSRA=(1<<ADEN);
	/*Select AD0*/
	ADMUX=0x00;
}

unsigned int read_adc(char channel){
	//Select Channel
	ADMUX=channel;
	//Start Convsersion
	ADCSRA|=(1<<ADSC);
	//Wait for Completion
	while(ADCSRA&(1<<ADSC));
	//Get the 10-bit values
	return (ADCL+(ADCH<<8));
}