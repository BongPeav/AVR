/*
 * 11-soft_twi_ds1307_sh1106.c
 *
 * Created: 2/9/2026 7:34:19 PM
 * Author : Admin
 */ 


#include<stdio.h>
#include <avr/io.h>
#include <util/delay.h>
#define F_CPU 16000000UL

#include "twi_device.h"

void rtc_init(void){
	char rtc[8]={0x30,0x35,0x13,0x07,0x31,0x01,0x26,1<<4};
	for (char i=0;i<8;i++)
	{
		twi_start();
		//D0 is DS1307 Write Address
		twi_write(DS1307_W);
		//Select Control Register
		twi_write(i);
		//Enable SQWE bit blinks at 1 Hz
		twi_write(rtc[i]);
		twi_stop();
		_delay_ms(10);
	}
}

unsigned char rtc[50], msg[20];
float voltage;
unsigned int temp;

void rtc_read(void){
	for(char i=0;i<50;i++){
		/*Second Register*/
		twi_start();
		twi_write(DS1307_W);
		/*Select Second register*/
		twi_write(i);		
		twi_stop();	
		_delay_us(100);
		
		twi_start();
		twi_write(DS1307_R);	
		rtc[i]=twi_read();	
		twi_stop();
		_delay_us(100);
	}
}
int main(void)
{
    /* Replace with your application code */
	_delay_ms(1000);
	display_init();
	adc_init();
	//rtc_init();
	display_clear(0);
	
	display_text_8x16(0,0,"Software TWI");
	display_text_8x16(0,1,"ATMega644P OLED");
	display_text_8x16(0,2,"SH1106 DS1307");
	display_text_8x16(0,3,"RTC Example");
	_delay_ms(10000);
	display_clear(0);
    while (1) 
    {	
		rtc_read();
		sprintf(msg,"Time: %02X:%02X:%02X",rtc[2],rtc[1],rtc[0]);
		display_text_8x16(0,0,msg);
		sprintf(msg,"Date: %02X/%02X/20%02X",rtc[4],rtc[5],rtc[6]);
		display_text_8x16(0,1,msg);
		
		//Read POT
		temp=read_adc(0);
		//Convert To Voltage
		voltage=temp*5.0/1023;
		sprintf(msg,"ADC0: %4d %.2fV",temp,voltage);
		display_text_8x16(0,2,msg);
		//Read LM35
		temp=read_adc(1);
		voltage=temp*5.0/1023;
		voltage*=100;
		sprintf(msg,"Temp: %.2f C",voltage);
		display_text_8x16(0,3,msg);
		_delay_us(500);
    }
}

