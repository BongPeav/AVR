#include "sh1106.h"

#include <string.h>
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <math.h>



void display_command(char command){
    twi_start();
    twi_write(0x78);
    twi_write(0x00);
    twi_write(command);
    twi_stop();
}

void display_data(char data){
    twi_start();
    twi_write(0x78);
    twi_write(0x40);
    twi_write(data);
    twi_stop();
}



void display_init(void){
     /*Display Off*/ 
    display_command(0xAE);  /*Set Lower Column Address*/ 
    display_command(0x02);  /*set higher column address*/  
    display_command(0x10);  /*set display start line*/ 
    display_command(0x40);  /*set page address*/ 
    display_command(0xB0);  /*contrast control*/  
    display_command(0x81);  /*set segment re-map*/
    display_command(0xFF);   
    display_command(0xA1);  /*normal - reverse*/   
    display_command(0xA6);  /*multiplex ratio*/  
    display_command(0xA8);  /*1/64 duty*/  
    display_command(0x3F);  /*enable charge pump*/  
    display_command(0xAD);  /*set Vpp 8V 0x30 - 0x33*/
    display_command(0x8B);    
    display_command(0x32);  /*COM scan direction*/    
    display_command(0xC8);  /*set display off-set*/    
    display_command(0xD3);
    display_command(0x00);  /*0x20*/
    display_command(0xD5);  /*set oscillator division*/
    display_command(0x80);
    display_command(0xD9);  /*set pre-charge period*/
    display_command(0x1F);  /*0x22*/
    display_command(0xDA);  /*set COM pin*/
    display_command(0x12);
    display_command(0xDB);  //set VCOMH
    display_command(0x40);
    display_command(0xAF);  //display ON
	
}

void display_xy(unsigned char x, unsigned char y){
    display_command(YLevel+y);
    display_command((((x+2)&0xF0)>>4)|0x10);
    display_command((x+2)&0x0F);
}

void display_char(char ch){
    if((ch<32)||(ch>127)) ch=' ';
    const char *base = &font_1[ch-32][0];
    char bytes[9];
    bytes[0]=0x40;
    memmove(bytes+1,base,8);
    
    twi_start();
    twi_write(0x78);
    twi_write(0x40);
    for(char i=1;i<=8;i++){ twi_write(bytes[i]);}
    twi_stop();
}

void display_clear(char data){
    for(char i=0;i<PAGE_SIZE;i++){
        display_command(YLevel+i);
        display_command(XLevelL);
        display_command(XLevelH);
        for(char n=0;n<WIDTH;n++){
            display_data(data);    
        }
    }
}

void display_text(char *txt){
    for(char i=0;i<strlen(txt);i++) display_char(txt[i]);
}

void display_char_8x16(unsigned char x, unsigned char y, char ch){
	y=y*2;
	display_xy(x,y);
	uint16_t temp;
	ch=ch-32;
	temp=ch*16;
	char i=0;
	for(i=0;i<8;i++) display_data(font_8x16[temp+i]);
	display_xy(x,y+1);
	for(i=8;i<16;i++) display_data(font_8x16[temp+i]);
	
}

void display_text_8x16(unsigned char x, unsigned char y, char *txt){
	while(*txt){  display_char_8x16(x,y,*txt++); x=x+8;}
}