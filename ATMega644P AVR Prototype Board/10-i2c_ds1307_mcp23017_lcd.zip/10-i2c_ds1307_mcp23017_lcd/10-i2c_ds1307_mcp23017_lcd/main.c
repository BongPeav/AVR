/*
 * 10-i2c_ds1307_mcp23017_lcd.c
 *
 * Created: 2/7/2026 7:42:39 PM
 * Author : Admin
 */ 

#include <avr/io.h>
#include <util/delay.h>
#define F_CPU 16000000UL

void rtc_init(void){
	char rtc[8]={0x30,0x00,0x17,0x07,0x31,0x01,0x26,1<<4};
	for (char i=0;i<8;i++)
	{
		twi_start();
		//D0 is DS1307 Write Address
		twi_write(0xD0);
		//Select Control Register
		twi_write(i);
		//Enable SQWE bit blinks at 1 Hz
		twi_write(rtc[i]);
		twi_stop();
		_delay_ms(10);
	}
}

char rtc[6], msg[16];
int main(void)
{
    /* Replace with your application code */
	_delay_ms(1000);
	lcd_init();
	lcd_text("ATMega644P TWI");
	lcd_xy(1,2);
	lcd_text("MCP23017 DS1307");
	
	_delay_ms(10000);
	lcd_clear();
	lcd_command(0x0C);
    while (1) 
    {
		for(char i=0;i<7;i++){
			/*Second Register*/
			twi_start();
			twi_write(0xD0);
			/*Select Second register*/
			twi_write(i);
			twi_stop();
			_delay_us(10);
					
			twi_start();
			twi_write(0xD1);
			rtc[i]=twi_read(1);
			twi_stop();
			_delay_us(10);		
		}
		
		lcd_xy(1,1);
		sprintf(msg,"Time: %02X:%02X:%02X",rtc[2],rtc[1],rtc[0]);
		lcd_text(msg);
		lcd_xy(1,2);
		sprintf(msg,"Date: %02X/%02X/20%02X",rtc[4],rtc[5],rtc[6]);
		lcd_text(msg);
		_delay_ms(500);
    }
}

