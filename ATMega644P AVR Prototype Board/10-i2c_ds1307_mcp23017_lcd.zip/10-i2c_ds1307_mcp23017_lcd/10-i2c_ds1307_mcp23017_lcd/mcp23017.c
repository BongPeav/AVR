/*
 * mcp23017.c
 *
 * Created: 2/5/2026 8:06:38 PM
 *  Author: Admin
 */ 
#include<stdio.h>
#include <avr/io.h>
#include <util/delay.h>
#define F_CPU 16000000UL

const char MCP23017_W=0x40;
const char MCP23017_R=0x41;


//IOCON.BANK=0

enum BANK0{
	IODIRA=0,IODIRB,IPOLA,IPOLB,GPINTENA,GPINTENB,DEFVALA,
	DEFVALB,INTCONA,INTCONB,IOCON1,IOCON2,GPPUA,GPPUB,
	INTFA,INTFB,INTCAPA,INTCAPB,GPIOA,GPIOB,OLATA,OLATB
};


void mcp23017_write(char address,char data){
	twi_start();
	/*Select the write address*/
	twi_write(MCP23017_W);
	/*Select a register address*/
	twi_write(address);
	/*Send configuration data*/
	twi_write(data);
	twi_stop();
}

unsigned char mcp23017_read(char address){
	/*Select a specific address*/
	twi_start();
	twi_write(MCP23017_W);
	twi_write(address);
	twi_stop();
	/*Read data from the given address*/
	twi_start();
	twi_write(MCP23017_R);
	unsigned char i2cData=twi_read(1);
	twi_stop();
	return i2cData;
}

const char RS=0,RW=1,EN=2;
char BLK_ON=0;

const char key_16[4][4]={'1','2','3','A',
	'4','5','6','B',
	'7','8','9','C',
'*','0','#','D'};

char keyScan(void){
	char data=0,temp,key;
	for(char i=0;i<4;i++){
		data=0xFF;
		data&=~(1<<i);
		mcp23017_write(OLATA,data);
		_delay_ms(5);
		data=mcp23017_read(GPIOA);
		data&=0xF0;
		if((data&0x10)==0)     {temp=key_16[i][0]; break;}
		else if((data&0x20)==0){temp=key_16[i][1]; break;}
		else if((data&0x40)==0){temp=key_16[i][2]; break;}
		else if((data&0x80)==0){temp=key_16[i][3]; break;}
		else temp=0;
		_delay_ms(10);
	}
	return temp;
}
void lcd_command(uint8_t temp){
	uint8_t command,led;
	command=temp&0xF0;
	if(BLK_ON==1) led=0x08;
	else led=0;
	mcp23017_write(OLATB,command|led|(1<<EN));
	_delay_us(10);
	mcp23017_write(OLATB,command|led);
	_delay_us(25);
	
	command=temp<<4;
	mcp23017_write(OLATB,command|led|(1<<EN));
	_delay_us(10);
	mcp23017_write(OLATB,command|led);
	_delay_us(25);
}

void lcd_data(uint8_t temp){
	uint8_t data,led;
	data=temp&0xF0;
	if(BLK_ON==1) led=0x08;
	else led=0;
	mcp23017_write(OLATB,data|led|(1<<EN)|(1<<RS));
	_delay_us(10);
	mcp23017_write(OLATB,data|led|(1<<RS));
	_delay_us(25);
	
	data=temp<<4;
	mcp23017_write(OLATB,data|led|(1<<EN)|(1<<RS));
	_delay_us(10);
	mcp23017_write(OLATB,data|led|(1<<RS));
	_delay_us(25);
}

void lcd_xy(uint8_t x, uint8_t y){
	uint8_t cursor[]={0x80,0xC0};
	lcd_command(cursor[y-1]+x-1);
}

void lcd_text(uint8_t *text){
	while(*text) lcd_data(*text++);
}

void lcd_clear(void){
	lcd_command(0x01);
	_delay_ms(5);
}

void lcd_init(void){
	BLK_ON=1;
	twi_init();
	mcp23017_write(IODIRB,0x00);
	lcd_command(0x33);
	_delay_us(10);
	lcd_command(0x32);
	_delay_us(10);
	lcd_command(0x28);
	_delay_us(10);
	lcd_command(0x0F);
	_delay_us(10);
	lcd_command(0x01);
	_delay_ms(5);
	lcd_command(0x06);
	_delay_us(10);
}