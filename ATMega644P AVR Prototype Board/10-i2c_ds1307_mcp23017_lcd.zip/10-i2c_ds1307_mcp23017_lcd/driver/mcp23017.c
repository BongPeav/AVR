/*
 * mcp23017.c
 *
 * Created: 2/5/2026 8:06:38 PM
 *  Author: Admin
 */ 

const char MCP23017_W=0x40;
const char MCP23017_R=0x41;

//IOCON.BANK=0
/*
enum BANK0{
	IODIRA=0,IODIRB,IPOLA,IPOLB,GPINTENA,GPINTENB,DEFVALA,
	DEFVALB,INTCONA,INTCONB,IOCON1,IOCON2,GPPUA,GPPUB,
	INTFA,INTFB,INTCAPA,INTCAPB,GPIOA,GPIOB,OLATA,OLATB
};
*/


void mcp23017_write(char address,char data){
	twi_start();
	/*Select the write address*/
	twi_write(MCP23017_W);
	/*Select a register address*/
	twi_write(address);
	/*Send configuration data*/
	twi_write(data);
	twi_stop();
}

unsigned char mcp23017_read(char address){
	/*Select a specific address*/
	twi_start();
	twi_write(MCP23017_W);
	twi_write(address);
	twi_stop();
	/*Read data from the given address*/
	twi_start();
	twi_write(MCP23017_R);
	unsigned char i2cData=twi_read(1);
	twi_stop();
	return i2cData;
}