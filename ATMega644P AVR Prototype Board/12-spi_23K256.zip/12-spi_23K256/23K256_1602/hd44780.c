/*
 * hd44780.c
 *
 * Created: 1/28/2026 9:55:18 PM
 *  Author: Admin
 */ 


#include "hd44780.h"


void lcd_command(char command){
	char temp;
	temp=command&0xF0;
	PORTC=temp|(1<<EN);
	_delay_us(d_time);
	PORTC=temp;
	_delay_us(d_time);
	
	temp=command<<4;
	PORTC=temp|(1<<EN);
	_delay_us(d_time);
	PORTC=temp;
	_delay_us(d_time);
}

void lcd_data(char data){
	char temp;
	temp=data&0xF0;
	PORTC=temp|(1<<EN)|(1<<RS);
	_delay_us(d_time);
	PORTC=temp|(1<<RS);
	_delay_us(d_time);
	
	temp=data<<4;
	PORTC=temp|(1<<EN)|(1<<RS);
	_delay_us(d_time);
	PORTC=temp|(1<<RS);
	_delay_us(d_time);
}
void lcd_init(void){
	DDRC=0xFF;
	lcd_command(0x33);
	_delay_us(100);
	lcd_command(0x32);
	_delay_us(100);
	lcd_command(0x28);
	_delay_us(100);
	lcd_command(0x0F);
	_delay_us(100);
	lcd_command(0x01);
	_delay_ms(5);
	lcd_command(0x06);
	_delay_us(100);
}
void lcd_xy(char x, char y){
	char addr[]={0x80,0xC0};
	lcd_command(addr[y-1]+x-1);
}
void lcd_text(char *text){
	while(*text) lcd_data(*text++);
}
void lcd_clear(void){
	lcd_command(0x01);
	_delay_ms(5);
}

