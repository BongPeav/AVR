/*
 * 23K256_1602.c
 *
 * Created: 2/25/2026 10:50:02 AM
 * Author : Admin
 */ 

#include <avr/io.h>
#include <util/delay.h>
#define F_CPU 16000000UL

#define DDR_SPI DDRB
#define PRT_SPI PORTB

#define DD_SS 4
#define DD_MOSI 5
#define DD_MISO 6
#define DD_SCK 7

void delay_1(unsigned int value){
	for (unsigned int i=0;i<value;i++)
	{
	}
}
void SPI_MasterInit(void)
{
	/* Set MOSI and SCK output, all others input */
	DDR_SPI = (1<<DD_MOSI)|(1<<DD_SCK)|(1<<DD_SS);
	/* Enable SPI, Master, set clock rate fck/16 */
	SPCR = (1<<SPE)|(1<<MSTR)|(1<<SPR0);
}

void SPI_MasterTransmit(char cData)
{
	/* Start transmission */
	SPDR = cData;
	/* Wait for transmission complete */
	while(!(SPSR & (1<<SPIF)))
	;
}

void SPI_SlaveInit(void)
{
	/* Set MISO output, all others input */
	DDR_SPI = (1<<DD_MISO);
	/* Enable SPI */
	SPCR = (1<<SPE);
}
char SPI_SlaveReceive(void)
{
	/* Wait for reception complete */
	while(!(SPSR & (1<<SPIF)))
	;
	/* Return Data Register */
	return SPDR;
}

// 23K256 SPI SRAM

void write_bytes_23K256(unsigned int address, unsigned char data){
	
	unsigned char temp;
	PRT_SPI&=~(1<<DD_SS);
	SPI_MasterTransmit(0x02);
	SPI_MasterTransmit(address>>8);
	SPI_MasterTransmit(address);
	SPI_MasterTransmit(data);
	PRT_SPI|=(1<<DD_SS);
	//delay_1(1000);
}

unsigned char read_bytes_23K256(unsigned int address){	
	PRT_SPI&=~(1<<DD_SS);
	SPI_MasterTransmit(0x03);
	SPI_MasterTransmit(address>>8);
	SPI_MasterTransmit(address);
	SPI_MasterTransmit(0xFF);	
	//delay_1(1000);
	unsigned char data=SPI_SlaveReceive();
	PRT_SPI|=(1<<DD_SS);
	return data;
}
int main(void)
{
    /* Replace with your application code */
	_delay_ms(50);
	SPI_MasterInit();
	PRT_SPI|=(1<<DD_SS);
	unsigned char temp=0, data[16];
	lcd_init();
	lcd_clear();	
	lcd_text("ATMega644P SRAM");
	lcd_xy(1,2);
	lcd_text("Serial 23K256");
	_delay_ms(10000);
	lcd_clear();
	
	for (unsigned int i=0;i<10;i++)
	{
		write_bytes_23K256(i,'0'+i);
	}
	for (unsigned int i=0;i<10;i++)
	{
		lcd_data(read_bytes_23K256(i));
	}
	
	lcd_xy(1,2);
	for (unsigned int i=0;i<16;i++)
	{	
		write_bytes_23K256(i+10,'A'+i);
	}
	for (unsigned int i=0;i<16;i++)
	{
		lcd_data(read_bytes_23K256(i+10));
	}
    while (1) 
    {
		
    }
}








