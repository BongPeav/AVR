/*
 * 23K256_Sequential_1602.c
 *
 * Created: 2/25/2026 2:37:30 PM
 * Author : Admin
 */ 

#include <avr/io.h>
#include <util/delay.h>
#define F_CPU 16000000UL
#include <stdio.h>

#define DDR_SPI DDRB
#define PRT_SPI PORTB

#define DD_SS 4
#define DD_MOSI 5
#define DD_MISO 6
#define DD_SCK 7

void delay_1(unsigned int value){
	for (unsigned int i=0;i<value;i++)
	{
	}
}
void SPI_MasterInit(void)
{
	/* Set MOSI and SCK output, all others input */
	DDR_SPI = (1<<DD_MOSI)|(1<<DD_SCK)|(1<<DD_SS);
	/* Enable SPI, Master, set clock rate fck/16 */
	SPCR = (1<<SPE)|(1<<MSTR)|(1<<SPR0);
}

void SPI_MasterTransmit(char cData)
{
	/* Start transmission */
	SPDR = cData;
	/* Wait for transmission complete */
	while(!(SPSR & (1<<SPIF)))
	;
}

void SPI_SlaveInit(void)
{
	/* Set MISO output, all others input */
	DDR_SPI = (1<<DD_MISO);
	/* Enable SPI */
	SPCR = (1<<SPE);
}
char SPI_SlaveReceive(void)
{
	/* Wait for reception complete */
	while(!(SPSR & (1<<SPIF)))
	;
	/* Return Data Register */
	return SPDR;
}

// 23K256 SPI SRAM

void write_bytes_23K256(unsigned int address, unsigned char data){
	
	unsigned char temp;
	PRT_SPI&=~(1<<DD_SS);
	SPI_MasterTransmit(0x02);
	SPI_MasterTransmit(address>>8);
	SPI_MasterTransmit(address);
	SPI_MasterTransmit(data);
	PRT_SPI|=(1<<DD_SS);
}

unsigned char read_bytes_23K256(unsigned int address){	
	PRT_SPI&=~(1<<DD_SS);
	SPI_MasterTransmit(0x03);
	SPI_MasterTransmit(address>>8);
	SPI_MasterTransmit(address);
	SPI_MasterTransmit(0xFF);	
	unsigned char data=SPI_SlaveReceive();
	PRT_SPI|=(1<<DD_SS);
	return data;
}

void write_sequential_23K256(unsigned int address, unsigned char *data){
	PRT_SPI&=~(1<<DD_SS);
	SPI_MasterTransmit(0x01);
	SPI_MasterTransmit(1<<6);
	PRT_SPI|=(1<<DD_SS);
	
	unsigned char temp;
	PRT_SPI&=~(1<<DD_SS);
	SPI_MasterTransmit(0x02);
	SPI_MasterTransmit(address>>8);
	SPI_MasterTransmit(address);
	while(*data)  { SPI_MasterTransmit(*data++); delay_1(10);}
	PRT_SPI|=(1<<DD_SS);
}

unsigned char data_read[32];
void read_sequential_23K256(unsigned int address,unsigned int size){
	PRT_SPI&=~(1<<DD_SS);
	SPI_MasterTransmit(0x01);
	SPI_MasterTransmit(1<<6);
	PRT_SPI|=(1<<DD_SS);
	
	unsigned char *temp;
	PRT_SPI&=~(1<<DD_SS);
	SPI_MasterTransmit(0x03);
	SPI_MasterTransmit(address>>8);
	SPI_MasterTransmit(address);
	for (unsigned int i=0;i<size;i++)
	{
		SPI_MasterTransmit(0xFF);
		data_read[i]=SPI_SlaveReceive();
		delay_1(10);
	}
	PRT_SPI|=(1<<DD_SS);
}

int main(void)
{
    /* Replace with your application code */
	_delay_ms(500);
	SPI_MasterInit();
	PRT_SPI|=(1<<DD_SS);

	lcd_init();
	lcd_clear();	
	
    while (1) 
    {
		
		lcd_xy(1,1);
		write_sequential_23K256(0,"ATMEGA644P SPI");
		for (unsigned int i=0;i<14;i++)
		{
			data_read[i]=read_bytes_23K256(i);
		}
		lcd_text(data_read);
		write_sequential_23K256(16,"23K256 SRAM    ");
		lcd_xy(1,2);
		read_sequential_23K256(16,16);
		lcd_text(data_read);
		_delay_ms(10000);
		lcd_clear();
		
		write_sequential_23K256(32,"ABCDEFGHIJKLMOPQ");
		lcd_xy(1,1);
		read_sequential_23K256(32,16);
		lcd_text(data_read);
		write_sequential_23K256(64,"RSTUVWXYZ !@#$%^");
		lcd_xy(1,2);
		read_sequential_23K256(64,16);
		lcd_text(data_read);
		_delay_ms(10000);
		lcd_clear();
		
    }
}









