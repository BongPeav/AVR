/*
 * 11-soft_twi_ds1307_lcd.c
 *
 * Created: 2/10/2026 3:03:24 PM
 * Author : Admin
 */ 

#include <avr/io.h>
#include <util/delay.h>
#define F_CPU 16000000UL

#define TWI_PORT PORTC
#define TWI_SDA_IN PINC
#define TWI_DIR  DDRC

const char SDA=1;
const char SCL=0;
const unsigned int PULSE=100;

//DS1307 and DS3231 RTC Chip
const char DS1307_W=0xD0;
const char DS1307_R=0xD1;
//AT24C16B 16kB EEPROM
const char AT24C16B_W=0xA0;
const char AT24C16B_R=0xA1;
//PCF8574 and PCF8574A Series
const char PCF8574_W=0x40;
const char PCF8574_R=0x41;
const char PCF8574A_W=0x70;
const char PCF8574A_R=0x71;
//DIY Arduino PCF8574T LCD Module
const char PCF8574T_LCD_W=0x4E;
const char PCF8574T_LCD_R=0x4F;
//SH1106 OLED Module
const char SH1106_W=0x78;
const char SH1106_R=0x79;
//MCP23017 GPIO Expansion
const char MCP23017_W=0x40;
const char MCP23017_R=0x41;

void delay_counts(unsigned int count){
	for(unsigned int i=0;i<count;i++);	
}

void twi_start(void){
	TWI_DIR|=(1<<SDA)|(1<<SCL);
	TWI_PORT|=(1<<SDA)|(1<<SCL);
	delay_counts(PULSE);
	TWI_PORT&=~(1<<SDA);
	delay_counts(PULSE);
	TWI_PORT&=~(1<<SCL);
	delay_counts(PULSE);
}

void twi_stop(void){
	TWI_DIR|=(1<<SDA)|(1<<SCL);
	TWI_PORT&=~(1<<SCL);
	TWI_PORT&=~(1<<SDA);
	TWI_PORT|=(1<<SCL);
	delay_counts(PULSE);
	TWI_PORT|=(1<<SDA);
	delay_counts(PULSE);
	TWI_PORT|=(1<<SDA)|(1<<SCL);
	delay_counts(PULSE);
}

void twi_write(char data){
	char temp=0;
	TWI_DIR|=(1<<SDA)|(1<<SCL);
	for (unsigned char i=0;i<9;i++)
	{
		TWI_PORT&=~(1<<SCL);
		delay_counts(PULSE);
		if(i<8){
			temp=data&0x80;
			if(temp==0) TWI_PORT&=~(1<<SDA);
			else TWI_PORT|=(1<<SDA);
		}		
		else{
			TWI_PORT&=~(1<<SDA);
			TWI_DIR&=~(1<<SDA);
			while(TWI_SDA_IN&(1<<SDA)==0);
		}	
		TWI_PORT|=(1<<SCL);
		delay_counts(PULSE);	
		data<<=1;
	}
	TWI_DIR|=(1<<SDA)|(1<<SCL);
}

char twi_read(void){
	char temp=0,data=0;
	TWI_DIR&=~(1<<SDA);
	for (unsigned char i=0;i<9;i++)
	{
		TWI_PORT&=~(1<<SCL);
		delay_counts(PULSE);
		TWI_PORT|=(1<<SCL);
		delay_counts(PULSE);
		
		
		
		if(i<8){
			/*
			data<<=1;
			temp=TWI_SDA_IN&(1<<SDA);
			if(temp==(1<<SDA)) data|=1;
			else data|=0;
			*/
			/*
			temp=TWI_SDA_IN&(1<<SDA);
			temp>>=1;
			data|=temp<<(7-i);						
			*/
			data<<=1;
			if (TWI_SDA_IN&(2))
			{
				data|=1;
			}
			
		}
		else{		
			while((TWI_SDA_IN&(1<<SDA))==0);		
					
		}
		
	}
	
	return data;
}

void rtc_init(void){
	char rtc[8]={0x30,0x10,0x21,0x04,0x11,0x02,0x26,1<<4};
	for (char i=0;i<8;i++)
	{
		twi_start();
		//D0 is DS1307 Write Address
		twi_write(DS1307_W);
		//Select Control Register
		twi_write(i);
		//Enable SQWE bit blinks at 1 Hz
		twi_write(rtc[i]);
		twi_stop();
		_delay_ms(10);
	}
}

char rtc[7], msg[16];
void rtc_read(void){
	for(char i=0;i<7;i++){
		/*Second Register*/
		twi_start();
		twi_write(DS1307_W);
		/*Select Second register*/
		twi_write(i);
		twi_stop();
		_delay_ms(10);
		
		twi_start();
		twi_write(DS1307_R);
		rtc[i]=twi_read();
		twi_stop();
		_delay_ms(10);
	}
}

int main(void)
{
    /* Replace with your application code */
	lcd_init();
	lcd_text("ATMega644P RTC");
	lcd_xy(1,2);
	lcd_text("Software TWI");
	_delay_ms(10000);
	lcd_clear();
	char count;
	lcd_command(0x0C);
	//rtc_init();
    while (1) 
    {
		rtc_read();		
		lcd_xy(1,1);
		sprintf(msg,"Time: %02X:%02X:%02X",rtc[2],rtc[1],rtc[0]);
		lcd_text(msg);
		lcd_xy(1,2);
		sprintf(msg,"Date: %02X/%02X/20%02X",rtc[4],rtc[5],rtc[6]);
		lcd_text(msg);
		
		_delay_ms(500);
    }
}

