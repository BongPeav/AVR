/*
 * twi_device.h
 *
 * Created: 2/10/2026 8:36:24 PM
 *  Author: Admin
 */ 


#ifndef TWI_DEVICE_H_
#define TWI_DEVICE_H_





#endif /* TWI_DEVICE_H_ */

//DS1307 and DS3231 RTC Chip
const char DS1307_W=0xD0;
const char DS1307_R=0xD1;
//AT24C16B 16kB EEPROM
const char AT24C16B_W=0xA0;
const char AT24C16B_R=0xA1;
//PCF8574 and PCF8574A Series
const char PCF8574_W=0x40;
const char PCF8574_R=0x41;
const char PCF8574A_W=0x70;
const char PCF8574A_R=0x71;
//DIY Arduino PCF8574T LCD Module
const char PCF8574T_LCD_W=0x4E;
const char PCF8574T_LCD_R=0x4F;
//SH1106 OLED Module
const char SH1106_W=0x78;
const char SH1106_R=0x79;
//MCP23017 GPIO Expansion
const char MCP23017_W=0x40;
const char MCP23017_R=0x41;