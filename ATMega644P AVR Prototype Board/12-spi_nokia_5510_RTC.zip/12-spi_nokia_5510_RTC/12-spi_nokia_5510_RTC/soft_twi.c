/*
 * soft_twi.c
 *
 * Created: 2/10/2026 7:31:12 PM
 *  Author: Admin
 */ 

#include <avr/io.h>


#define TWI_PORT PORTC
#define TWI_SDA_IN PINC
#define TWI_DIR  DDRC

const char SDA=1;
const char SCL=0;
const unsigned int PULSE=100;

void delay_counts(unsigned int count){
	for(unsigned int i=0;i<count;i++);	
}
/*
void twi_start(void){
	TWI_DIR|=(1<<SDA)|(1<<SCL);
	TWI_PORT|=(1<<SDA)|(1<<SCL);
	delay_counts(PULSE);
	TWI_PORT&=~(1<<SDA);
	delay_counts(PULSE);
	TWI_PORT&=~(1<<SCL);
	delay_counts(PULSE);
}

void twi_stop(void){
	TWI_DIR|=(1<<SDA)|(1<<SCL);
	TWI_PORT&=~(1<<SCL);
	TWI_PORT&=~(1<<SDA);
	TWI_PORT|=(1<<SCL);
	delay_counts(PULSE);
	TWI_PORT|=(1<<SDA);
	delay_counts(PULSE);
	TWI_PORT|=(1<<SDA)|(1<<SCL);
	delay_counts(PULSE);
}
*/

void twi_start(void){
	TWI_DIR=(1<<SDA)|(1<<SCL);
	TWI_PORT=(1<<SDA)|(1<<SCL);
	delay_counts(20);
	TWI_PORT&=~(1<<SDA);
	delay_counts(10);
	TWI_PORT&=~(1<<SCL);
	delay_counts(10);
}

void twi_stop(void){
	TWI_PORT&=~(1<<SCL);
	TWI_PORT&=~(1<<SDA);
	TWI_PORT|=(1<<SCL);
	delay_counts(10);
	TWI_PORT|=(1<<SDA);
	delay_counts(10);
	TWI_PORT=(1<<SDA)|(1<<SCL);
	delay_counts(20);
}

void twi_write(char data){
	char temp=0;
	TWI_DIR|=(1<<SDA)|(1<<SCL);
	for (unsigned char i=0;i<9;i++)
	{
		TWI_PORT&=~(1<<SCL);
		delay_counts(PULSE);
		if(i<8){
			temp=data&0x80;
			if(temp==0) TWI_PORT&=~(1<<SDA);
			else TWI_PORT|=(1<<SDA);
		}		
		else{
			TWI_PORT&=~(1<<SDA);
			TWI_DIR&=~(1<<SDA);
			while(TWI_SDA_IN&(1<<SDA)==0);
		}	
		TWI_PORT|=(1<<SCL);
		delay_counts(PULSE);	
		data<<=1;
	}
	TWI_DIR|=(1<<SDA)|(1<<SCL);
}

char twi_read(void){
	unsigned char temp=0,data=0;
	TWI_DIR&=~(1<<SDA);
	for (unsigned char i=0;i<9;i++)
	{
		TWI_PORT&=~(1<<SCL);
		delay_counts(PULSE);
		TWI_PORT|=(1<<SCL);
		delay_counts(PULSE);
		if(i<8){
			/*
			data<<=1;
			temp=TWI_SDA_IN&(1<<SDA);
			if(temp==(1<<SDA)) data|=1;
			else data|=0;
			*/
			
			temp=TWI_SDA_IN&(1<<SDA);
			temp>>=1;
			data|=temp<<(7-i);						
			
			/*
			data<<=1;
			if (TWI_SDA_IN&(2))
			{
				data|=1;				
			}
			*/
		}
		else{		
			while(TWI_SDA_IN&(1<<SDA)==0);					
		}
		
	}
	return data;
}