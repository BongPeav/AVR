/*
 * soft_twi.c
 *
 * Created: 2/12/2026 4:06:53 PM
 *  Author: Admin
 */ 

#include <avr/io.h>

#define TWI_PORT PORTC
#define TWI_SDA_IN PINC
#define TWI_DIR  DDRC

const char SDA=1;
const char SCL=0;
const unsigned int PULSE=100;

//DS1307 and DS3231 RTC Chip
const char DS1307_W=0xD0;
const char DS1307_R=0xD1;
//AT24C16B 16kB EEPROM
const char AT24C16B_W=0xA0;
const char AT24C16B_R=0xA1;
//PCF8574 and PCF8574A Series
const char PCF8574_W=0x40;
const char PCF8574_R=0x41;
const char PCF8574A_W=0x70;
const char PCF8574A_R=0x71;
//DIY Arduino PCF8574T LCD Module
const char PCF8574T_LCD_W=0x4E;
const char PCF8574T_LCD_R=0x4F;
//SH1106 OLED Module
const char SH1106_W=0x78;
const char SH1106_R=0x79;
//MCP23017 GPIO Expansion
const char MCP23017_W=0x40;
const char MCP23017_R=0x41;

void delay_counts(unsigned int count){
	for(unsigned int i=0;i<count;i++);	
}

void twi_start(void){
	TWI_DIR|=(1<<SDA)|(1<<SCL);
	TWI_PORT|=(1<<SDA)|(1<<SCL);
	delay_counts(PULSE);
	TWI_PORT&=~(1<<SDA);
	delay_counts(PULSE);
	TWI_PORT&=~(1<<SCL);
	delay_counts(PULSE);
}

void twi_stop(void){
	TWI_DIR|=(1<<SDA)|(1<<SCL);
	TWI_PORT&=~(1<<SCL);
	TWI_PORT&=~(1<<SDA);
	TWI_PORT|=(1<<SCL);
	delay_counts(PULSE);
	TWI_PORT|=(1<<SDA);
	delay_counts(PULSE);
	TWI_PORT|=(1<<SDA)|(1<<SCL);
	delay_counts(PULSE);
}

void twi_write(char data){
	char temp=0;
	TWI_DIR|=(1<<SDA)|(1<<SCL);
	for (unsigned char i=0;i<9;i++)
	{
		TWI_PORT&=~(1<<SCL);
		delay_counts(PULSE);
		if(i<8){
			temp=data&0x80;
			if(temp==0) TWI_PORT&=~(1<<SDA);
			else TWI_PORT|=(1<<SDA);
		}		
		else{
			TWI_PORT&=~(1<<SDA);
			TWI_DIR&=~(1<<SDA);
			while(TWI_SDA_IN&(1<<SDA)==0);
		}	
		TWI_PORT|=(1<<SCL);
		delay_counts(PULSE);	
		data<<=1;
	}
	TWI_DIR|=(1<<SDA)|(1<<SCL);
}

char twi_read(void){
	char temp=0,data=0;
	TWI_DIR&=~(1<<SDA);
	for (unsigned char i=0;i<9;i++)
	{
		TWI_PORT&=~(1<<SCL);
		delay_counts(PULSE);
		TWI_PORT|=(1<<SCL);
		delay_counts(PULSE);
		
		
		
		if(i<8){
			/*
			data<<=1;
			temp=TWI_SDA_IN&(1<<SDA);
			if(temp==(1<<SDA)) data|=1;
			else data|=0;
			*/
			/*
			temp=TWI_SDA_IN&(1<<SDA);
			temp>>=1;
			data|=temp<<(7-i);						
			*/
			data<<=1;
			if (TWI_SDA_IN&(2))
			{
				data|=1;
			}		
		}
		else{		
			while((TWI_SDA_IN&(1<<SDA))==0);		
					
		}		
	}	
	return data;
}

//PCF8574T LCD Driver

void pcf8574_write(char data){
	twi_start();
	twi_write(PCF8574T_LCD_W);
	twi_write(data);
	twi_stop();
}

char pcf8574_read(void){
	twi_start();
	twi_write(PCF8574T_LCD_R);
	char temp=twi_read();
	twi_stop();
	return temp;
}

// HD44780 LCD PCF8574T

/*TWI LCD Driver*/
#define RS  0
#define RW  1
#define EN  2
#define BL  3

char backLight=1;

void twi_lcd_command(uint8_t command){
	uint8_t data;
	data=command&0xF0;
	pcf8574_write(data|(backLight<<BL)|(1<<EN));
	//_delay_us(10);
	pcf8574_write(data|(backLight<<BL));
	//_delay_us(50);

	data=command<<4;
	pcf8574_write(data|(backLight<<BL)|(1<<EN));
	//_delay_us(10);
	pcf8574_write(data|(backLight<<BL));
	//_delay_us(50);
}

void twi_lcd_data(uint8_t command){
	uint8_t data;
	data=command&0xF0;
	pcf8574_write(data|(backLight<<BL)|(1<<EN)|(1<<RS));
	//_delay_us(10);
	pcf8574_write(data|(backLight<<BL)|(1<<RS));
	//_delay_us(50);

	data=command<<4;
	pcf8574_write(data|(backLight<<BL)|(1<<EN)|(1<<RS));
	//_delay_us(10);
	pcf8574_write(data|(backLight<<BL)|(1<<RS));
	//_delay_us(50);
}

void twi_lcd_xy(int8_t x, int8_t y){
	int8_t addr[]={0x80,0xC0};
	twi_lcd_command(addr[y-1]+x-1);
}

void twi_lcd_text(int8_t *txt){
	while(*txt) twi_lcd_data(*txt++);
}

void twi_lcd_clear(void){
	twi_lcd_command(0x01);
	delay_counts(5000);
}

void twi_lcd_cursor_off(void){
	twi_lcd_command(0x0C);
}

void twi_lcd_line_1(void){
	twi_lcd_command(0x80);
}

void twi_lcd_line_2(void){
	twi_lcd_command(0xC0);
}

void twi_lcd_init(void){
	pcf8574_write(0);
	//_delay_ms(10);
	twi_lcd_command(0x33);
	//_delay_us(10);
	twi_lcd_command(0x32);
	//_delay_us(10);
	twi_lcd_command(0x28);
	//_delay_us(10);
	twi_lcd_command(0x0F);
	//_delay_us(10);
	twi_lcd_command(0x01);
	//_delay_ms(5);
	twi_lcd_command(0x06);
	//_delay_us(10);
}
