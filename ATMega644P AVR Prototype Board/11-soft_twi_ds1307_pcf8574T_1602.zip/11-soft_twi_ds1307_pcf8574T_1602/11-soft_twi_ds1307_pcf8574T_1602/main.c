/*
 * 11-soft_twi_ds1307_pcf8574T_1602.c
 *
 * Created: 2/12/2026 5:21:17 PM
 * Author : Admin
 */ 

#include <avr/io.h>
#include <util/delay.h>
#define F_CPU 16000000UL

char rtc[7], msg[16];
void rtc_read(void){
	for(char i=0;i<7;i++){
		/*Second Register*/
		twi_start();
		twi_write(0xD0);
		/*Select Second register*/
		twi_write(i);
		twi_stop();
		_delay_ms(10);
		
		twi_start();
		twi_write(0xD1);
		rtc[i]=twi_read();
		twi_stop();
		_delay_ms(10);
	}
}

void rtc_init(void){
	char rtc[8]={0x30,0x10,0x21,0x04,0x11,0x02,0x26,1<<4};
	for (char i=0;i<8;i++)
	{
		twi_start();
		//D0 is DS1307 Write Address
		twi_write(0xD0);
		//Select Control Register
		twi_write(i);
		//Enable SQWE bit blinks at 1 Hz
		twi_write(rtc[i]);
		twi_stop();
		_delay_ms(10);
	}
}

int main(void)
{
    /* Replace with your application code */
	twi_lcd_init();
	twi_lcd_text("Software TWI");
	twi_lcd_line_2();
	twi_lcd_text("DS1307 PCF8574T");
	_delay_ms(10000);
	twi_lcd_clear();
	twi_lcd_cursor_off();
    while (1) 
    {
		rtc_read();
		twi_lcd_line_1();
		sprintf(msg,"Time: %02X:%02X:%02X",rtc[2],rtc[1],rtc[0]);
		twi_lcd_text(msg);
		twi_lcd_line_2();
		sprintf(msg,"Date: %02X/%02X/20%02X",rtc[4],rtc[5],rtc[6]);
		twi_lcd_text(msg);
		
		_delay_ms(500);
    }
}

