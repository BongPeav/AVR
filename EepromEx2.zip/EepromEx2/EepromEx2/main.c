/*
 * EepromEx2.c
 *
 * Created: 7/20/2023 9:16:24 PM
 * Author : Admin
 */ 

#include <avr/io.h>

#define F_CPU 8000000UL
#include <util/delay.h>

#include <avr/eeprom.h>

const uint8_t myData[]  EEMEM = {0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80};
	
int main(void)
{
    DDRC=0xFF;
    while (1) 
    {	
		for (int i =0;i<sizeof(myData);i++)
		{
			char temp = &myData[i];
			PORTC=eeprom_read_byte(temp);
			_delay_ms(1000);
		}
		
    }
}

