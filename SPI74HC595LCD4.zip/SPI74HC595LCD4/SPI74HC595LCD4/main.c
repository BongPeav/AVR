/*
 * SPI74HC595LCD4.c
 *
 * Created: 7/9/2023 6:10:20 PM
 * Author : Admin
 */ 

#include <avr/io.h>

#define F_CPU 4000000UL
#include <util/delay.h>

void masterInit(void){
	/*Set MOSI, SCK and SS Output*/
	DDRB|=(1<<4)|(1<<5)|(1<<7);
	/*Enable SPI Master Set Clock Rate Fclk/4*/
	SPCR|=(1<<SPE)|(1<<MSTR);
}

void masterTransmit(unsigned char spiData){
	/*Start The Transmission*/
	SPDR = spiData;
	/*Wait For Completion*/
	while(!(SPSR&(1<<SPIF)));
}

void send74hc164(unsigned char data){
	masterTransmit(data);
	PORTB|=(1<<4);
	for(int i = 0; i<=10; i++);
	PORTB&=~(1<<4);
}

unsigned char DPORT;
unsigned char temp;

void lcdCmd(unsigned char cmd){
	
	temp=0x02;
	DPORT=(cmd&0xF0)|(temp);
	send74hc164(DPORT);
	_delay_us(100);
	temp=0x00;
	DPORT=(cmd&0xF0)|(temp);
	send74hc164(DPORT);
	_delay_us(10);
	
	temp=0x02;
	DPORT=(cmd<<4)|(temp);
	send74hc164(DPORT);
	_delay_us(10);
	temp=0x00;
	DPORT=(cmd<<4)|(temp);
	send74hc164(DPORT);
}

void lcdDat(unsigned char dat){	
	temp=0x03;
	DPORT=temp|(dat&0xF0);
	send74hc164(DPORT);
	_delay_us(10);
	temp=0x01;
	DPORT=temp|(dat&0xF0);
	send74hc164(DPORT);
	_delay_us(100);
	
	temp=0x03;
	DPORT=temp|(dat<<4);
	send74hc164(DPORT);
	_delay_us(10);
	temp=0x01;
	DPORT=temp|(dat<<4);
	send74hc164(DPORT);
		
}

void lcdInit(){
	DPORT=0x00;
	send74hc164(0x00);
	_delay_ms(20);
	lcdCmd(0x33);
	_delay_us(100);
	lcdCmd(0x32);
	_delay_us(100);
	lcdCmd(0x28);
	_delay_us(100);
	
	lcdCmd(0x0E);
	_delay_us(100);
	lcdCmd(0x01);
	_delay_ms(2);
	lcdCmd(0x06);
	_delay_us(100);
}

void lcdStr( char *str){
	unsigned char i=0;
	while(str[i]!=0){
		lcdDat(str[i]);
		i++;
	}
}

void lcdXY(unsigned char x, unsigned char y){
	unsigned char tbe[]={0x80,0xC0,0x94,0xD4};	// 20x4
	lcdCmd(tbe[y-1]+x-1);
	_delay_us(100);
}

void lcdClear(){
	lcdCmd(0x01);
	_delay_us(10);
}


int main(void)
{
    masterInit();
	lcdInit();
	
	//lcdXY(1,1);
	lcdStr("Hello World!");
	
	lcdXY(1,2);
	lcdStr("ATMega32 SN74HC595");
	
	lcdXY(1,3);
	lcdStr("LCD Interfacing");
	
	lcdXY(1,4);
	
	lcdStr("Microchip Studio");
	lcdCmd(0x0F);
	_delay_ms(100);
		
    while (1) 
    {			
    }
}




