/*
 * Example_2.c
 *
 * Created: 7/19/2023 1:52:49 PM
 * Author : Admin
 */ 

#include <avr/io.h>
#include <avr/pgmspace.h>
#define F_CPU 8000000UL
#include "util/delay.h"

/*Declare constant data that will store in program Flash Memory*/
const char cCathode[] PROGMEM = {0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F,0x77,0x7C,0x39,0x5E,0x79,0x71};
const  char cAnode[] PROGMEM = {0xC0,0xF9,0xA4,0xB0,0x99,0x92,0x82,0xF8,0x80,0x90,0x88,0x83,0xC6,0xA1,0x86,0x8E};

int main(void)
{
    DDRC = 0xFF;
    while (1) 
    {
		for (char i=0;i<16;i++)
		{
			/*Read Flash Data and assign to PORTC*/
			PORTC = pgm_read_byte(&cCathode[i]);
			_delay_ms(500);
		}
    }
}

