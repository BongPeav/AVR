/*
 * RT12864Test4.c
 *
 * Created: 7/15/2023 11:57:20 AM
 * Author : Admin
 */ 

#include <avr/io.h>
#include "font5x8.h"
#include "diy-logo.h"

#define F_CPU 8000000UL
#include <util/delay.h>

#define LCD_DATA PORTC
#define LCD_CONT PORTD

#define LCD_EN		0
#define LCD_DI		1
#define LCD_CS1		2
#define LCD_CS2		3
#define LCD_RST		4

unsigned char dotCount=0;

void lcdCommand(unsigned char cmd,char cs){
	if(cs==1) LCD_CONT|=(1<<LCD_CS1);
	else if(cs==2) LCD_CONT|=(1<<LCD_CS2);
	LCD_CONT&=~(1<<LCD_DI);
	LCD_CONT|=(1<<LCD_EN);
	LCD_DATA=cmd;
	LCD_CONT&=~(1<<LCD_EN);
	_delay_us(10);
	if(cs==1) LCD_CONT&=~(1<<LCD_CS1);
	else if(cs==2) LCD_CONT&=~(1<<LCD_CS2);
}

void lcdData(char  data,char cs){
	if(cs==1) LCD_CONT|=(1<<LCD_CS1);
	else if(cs==2) LCD_CONT|=(1<<LCD_CS2);
	LCD_CONT|=(1<<LCD_DI);
	LCD_CONT|=(1<<LCD_EN);
	LCD_DATA=data;
	LCD_CONT&=~(1<<LCD_EN);
	_delay_us(10);
	if(cs==1) LCD_CONT&=~(1<<LCD_CS1);
	else if (cs==2) LCD_CONT&=~(1<<LCD_CS2);
}

void lcdHorizontal(unsigned char horizontal){
	lcdCommand(0x40+horizontal,1);
	lcdCommand(0x40+horizontal,2);
	
}

void lcdVerticalLine(unsigned char line){
	lcdCommand(0xB8+line,1);
	lcdCommand(0xB8+line,2);
	dotCount=0;
}

void lcdSetZ(unsigned char zAxis){
	lcdCommand(0xC0+zAxis,1);
	lcdCommand(0xC0+zAxis,2);
}

void lcdXy(unsigned char x,unsigned char y){
	if(x<64){
		lcdCommand(0x40+x,1);
		lcdCommand(0x40+0,2);
	}
	else{
		lcdCommand(0x40+0,1);
		lcdCommand(0x40+x-63,2);
	}
	
	lcdCommand(0xB8+y,1);
	lcdCommand(0xB8+y,2);
	dotCount=x;
}

void writeChar(unsigned char aph){
	for (int i=0;i<5;i++)
	{
		if(dotCount<64) lcdData(font5x8[((aph-32)*5)+i],1);
		else lcdData(font5x8[((aph-32)*5)+i],2);
		dotCount++;
	}
	lcdData(0,(dotCount<64)?1:2);
	dotCount++;
	if (dotCount>127)
	{
		dotCount=0;
	}
}

void writeCharDelay(unsigned char aph,unsigned int dT){
	for (int i=0;i<5;i++)
	{
		if(dotCount<64) lcdData(font5x8[((aph-32)*5)+i],1);
		else lcdData(font5x8[((aph-32)*5)+i],2);
		if(dT!=0) for(int i=0;i<dT;i++) _delay_us(1000);
		dotCount++;
	}
	lcdData(0,(dotCount<64)?1:2);
	dotCount++;
	if (dotCount>127)
	{
		dotCount=0;
	}
}

void lcdString(char *str){
	while(*str)
		writeChar(*str++);
}

void writeStringDelay(char *str,unsigned int dT){
	while(*str){		
		if(dT!=0) writeCharDelay(*str++,dT);
		else writeChar(*str++);
	}
}

void lcdInit(void){
	DDRC=0xFF;
	DDRD=0xFF;
	/*Display On*/
	lcdCommand(0x3F,1);
	lcdCommand(0x3F,2);
	dotCount = 0;
}

void lcdClearScreen(){
	
	for (int i=0;i<8;i++)
	{
		lcdXy(0,i);
		for(int j=0;j<128;j++){
			lcdData(0,1);
			lcdData(0,2);
		}
	}	
	dotCount=0;
	lcdXy(0,0);
}

void lcdClearSection(unsigned char x,unsigned char y,unsigned char dot){
	lcdXy(x,y);
	dotCount=x;
	for (int i=0;i<dot;i++)
	{
		if(dotCount<64) lcdData(0,1);
		else lcdData(0,2);
		dotCount++;
	}

	if (dotCount>127)
	{
		dotCount=0;
	}
}

void showGraphic(void){
	unsigned int kCount=0;
	for (int i=0;i<8;i++)
	{
		
		dotCount=0;
		lcdXy(0,i);
		for (int j=kCount;j<kCount+128;j++)
		{
			if(dotCount<64) lcdData(logo[j],1);
			else lcdData(logo[j],2);
			dotCount++;
		}
		kCount+=128;
	}
}

int main(void)
{
	lcdInit();
	lcdClearScreen();
	while (1)
	{
		lcdXy(25,0);
		writeStringDelay("HELLO WORLD!",10);
		lcdXy(0,1);
		writeStringDelay("ATMEGA32 Graphic LCD ",10);
		lcdXy(0,2);
		writeStringDelay("Programming in C With",10);
		lcdXy(0,3);
		writeStringDelay("Microchip Studio",10);
		lcdXy(0,4);
		writeStringDelay("DIY-Instruments",10);
		lcdXy(0,5);
		writeStringDelay("KS0108 LCD Controller",10);
		lcdXy(0,6);
		writeStringDelay("RT12864J-1 128x64",10);
		lcdXy(0,7);
		writeStringDelay("Graphical LCD Module",10);
		_delay_ms(5000);
		lcdClearScreen();
		
		lcdXy(0,0);
		showGraphic();
		_delay_ms(5000);
		lcdClearScreen();
	}
}




