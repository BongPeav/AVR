/*
 * SN74HC164LEDBitBang.c
 *
 * Created: 7/7/2023 7:18:00 PM
 * Author : Admin
 */ 

#include <avr/io.h>

#define SDAT 7
#define SCLK 6

void send74hc164(unsigned char data){
	for(int i=0; i<8;i++){
		if ((data&(1<<7))==0)
		{
			PORTC&=~(1<<SDAT);		
		}
		else PORTC|=(1<<SDAT);
		PORTC|=(1<<SCLK);
		for(int i=0;i<=50;i++);
		PORTC&=~(1<<SCLK);
		for(int i=0;i<=50;i++);
		data<<=1;
	}	
}

int main(void)
{
	unsigned char newData = 0, oldData = 0;
		
	DDRC|=(1<<SDAT)|(1<<SCLK);  
	DDRB=0x00;
	PORTB=0xFF;  
    while (1) 
    {
		newData = PINB;
		if (newData!=oldData)
		{		
			send74hc164(newData);
			oldData = newData;
		}
    }
}

