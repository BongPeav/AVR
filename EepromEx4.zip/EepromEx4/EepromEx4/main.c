/*
 * EepromEx4.c
 *
 * Created: 7/21/2023 9:21:18 AM
 * Author : Admin
 */ 

#include <avr/io.h>

#define F_CPU 8000000UL
#include <util/delay.h>

#include <avr/eeprom.h>

#define Write (PIND&0x08)==0
#define LED		7

/*Declare EEPROM Storage*/
uint8_t Edata[256] EEMEM;

const uint8_t cAnode[]  = {0xC0,0xF9,0xA4,0xB0,0x99,0x92,0x82,0xF8,0x80,0x90,0x88,0x83,0xC6,0xA1,0x86,0x8E};
	
int main(void)
{
    uint8_t oldAddr=1,newAddr=0,segment=0,inputData;
	DDRA=0x00;
	PINA=0xFF;
	DDRC=0xFF;
	PORTC=0xFF;
	DDRD=0x07;
	PORTD=0xF8;
    while (1) 
    {
		/*Check Address Change*/
		if (newAddr!=oldAddr)
		{
			segment = eeprom_read_byte(&Edata[newAddr]);		
			oldAddr = newAddr;			
		}
	    PORTC = cAnode[segment];
		newAddr = PINA;	
		if (Write)
		{
			PORTC&=~(1<<LED);
			inputData = (PIND&0xF0)>>4;
			eeprom_write_byte(&Edata[newAddr],inputData);		
			while(Write);			
			segment = eeprom_read_byte(&Edata[newAddr]);
			PORTC|=(1<<LED);
		}		
    }
}

