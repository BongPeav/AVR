/*
 * 10-i2c_sh1106_ds1307.c
 *
 * Created: 2/8/2026 8:34:30 PM
 * Author : Admin
 */ 

#define F_CPU 16000000UL
#include<stdio.h>
#include <avr/io.h>
#include <util/delay.h>

void rtc_init(void){
	char rtc[8]={0x30,0x35,0x13,0x07,0x31,0x01,0x26,1<<4};
	for (char i=0;i<8;i++)
	{
		twi_start();
		//D0 is DS1307 Write Address
		twi_write(0xD0);
		//Select Control Register
		twi_write(i);
		//Enable SQWE bit blinks at 1 Hz
		twi_write(rtc[i]);
		twi_stop();
		_delay_ms(10);
	}
}

void adc_init(void){
	/*Set PA0 and PA1 to input*/
	DDRA&=~(1<<0);
	DDRA&=~(1<<1);
	ADCSRA=(1<<ADEN);
	/*Select AD0*/
	ADMUX=0x00;
}

unsigned int read_adc(char channel){
	//Select Channel
	ADMUX=channel;
	_delay_us(100);
	//Start Convsersion
	ADCSRA|=(1<<ADSC);
	//Wait for Completion
	while(ADCSRA&(1<<ADSC));
	//Get the 10-bit values
	return (ADCL+(ADCH<<8));
}

char rtc[6], msg[16];
float voltage;
unsigned int temp;
int main(void)
{
    /* Replace with your application code */
	_delay_ms(1000);
	display_init();
	adc_init();
	display_clear(0);
	display_text_8x16(0,0,"ATMega32 TWI");
	display_text_8x16(0,1,"SH1106 OLED");
	display_text_8x16(0,2,"and DS1307");
	display_text_8x16(0,3,"RTC Example");
	_delay_ms(10000);
	display_clear(0);
    while (1) 
    {
		for(char i=0;i<7;i++){
			/*Second Register*/
			twi_start();
			twi_write(0xD0);
			/*Select Second register*/
			twi_write(i);
			twi_stop();
			_delay_us(10);
			
			
			twi_start();
			twi_write(0xD1);
			rtc[i]=twi_read(1);
			twi_stop();
			_delay_us(10);		
		}
		
		sprintf(msg,"Time: %02X:%02X:%02X",rtc[2],rtc[1],rtc[0]);
		display_text_8x16(0,0,msg);
		sprintf(msg,"Date: %02X/%02X/20%02X",rtc[4],rtc[5],rtc[6]);
		display_text_8x16(0,1,msg);
		
		//Read POT
		temp=read_adc(0);
		//Convert To Voltage
		voltage=temp*5.0/1023;
		sprintf(msg,"ADC0: %4d %.2fV",temp,voltage);
		display_text_8x16(0,2,msg);
		//Read LM35
		temp=read_adc(1);
		voltage=temp*5.0/1023;
		voltage*=100;
		sprintf(msg,"Temp: %0.1f Degree",voltage);
		display_text_8x16(0,3,msg);
		_delay_ms(500);
    }
}

