/*
 * 10-twi_sh1106.c
 *
 * Created: 2/7/2026 5:21:04 PM
 * Author : Admin
 */ 

#define F_CPU	16000000UL
#include <avr/io.h>
#include <util/delay.h>

void show_text(void){
	display_xy(0,0);
	display_text("ATMega32 SH1106");
	display_xy(0,1);
	display_text("TWI Programming");
	display_xy(0,2);
	display_text("Microchip Studio");
	display_xy(0,3);
	display_text("v.7.0.2542");
	display_xy(0,4);
	display_text("1.3 I2C OLED ");
	display_xy(0,5);
	display_text("Display Module");
	display_xy(0,6);
	display_text("AKI-Technical");
	display_xy(0,7);
	display_text("2026/02/08 Sun");
}

int main(void)
{
    /* Replace with your application code */
	_delay_ms(1000);
	display_init();
	display_clear(0);
	show_text();
	_delay_ms(5000);
	display_clear(0);
    while (1) 
    {
		
		display_clear(0);
		show_text();
		_delay_ms(2500);
		display_clear(0);
		_delay_ms(2500);
		display_clear(0xFF);
		_delay_ms(2500);
		display_clear(0);
		show_text();
		_delay_ms(2500);
		display_clear(0xAA);
		_delay_ms(2500);
		
    }
}

