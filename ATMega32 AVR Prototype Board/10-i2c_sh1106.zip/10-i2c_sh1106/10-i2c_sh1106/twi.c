/*
 * twi.c
 *
 * Created: 2/4/2026 10:22:02 AM
 *  Author: Admin
 */ 

#define F_CPU 16000000UL

#include <avr/io.h>
#include <util/delay.h>



void twi_init(void){
	TWSR|=0x01; //Prescaler Selection Bit
	TWBR=0x01; //Baud Rate Generator
	TWCR=(1<<TWEN); //Enable The TWI Module
	PORTC|=(1<<0);
	PORTC|=(1<<1);
}

void twi_start(void){
	TWCR=(1<<TWINT)|(1<<TWSTA)|(1<<TWEN);
	while((TWCR&(1<<TWINT))==0);
}

void twi_write(unsigned char data){
	TWDR=data;
	TWCR=(1<<TWINT)|(1<<TWEN);
	while((TWCR&(1<<TWINT))==0);
}

unsigned char twi_read(char ACK){
	if(ACK==0)
	TWCR=(1<<TWINT)|(1<<TWEN)|(1<<TWEA);
	else
	TWCR=(1<<TWINT)|(1<<TWEN);
	while((TWCR&(1<<TWINT))==0);
	return TWDR;
}

void twi_stop(){
	TWCR=(1<<TWINT)|(1<<TWEN)|(1<<TWSTO);
	//_delay_us(100);
}