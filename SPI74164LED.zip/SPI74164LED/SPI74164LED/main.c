/*
 * SPI74164LED.c
 *
 * Created: 7/7/2023 9:16:53 AM
 * Author : Admin
 */ 

#include <avr/io.h>

#define F_CPU 4000000UL
#include <util/delay.h>

void masterInit(void){
	/*Set MOSI, SCK and SS Output*/
	DDRB|=(1<<4)|(1<<5)|(1<<7);
	/*Enable SPI Master Set Clock Rate Fclk/4*/
	SPCR|=(1<<SPE)|(1<<MSTR);
}

void masterTransmit(char spiData){
	/*Start The Transmission*/
	SPDR = spiData;
	/*Wait For Completion*/
	while(!(SPSR&(1<<SPIF)));
}


int main(void)
{
    masterInit();
	
    while (1) 
    {
		masterTransmit(0xF0);
		_delay_ms(1000);
		masterTransmit(0xAA);
		_delay_ms(1000);
		masterTransmit(0x0F);
		_delay_ms(1000);
    }
}

